<?php

namespace App\Controllers;

class AdminDashboard extends BaseController
{
    public function index()
    {
        if (!session()->get('isLoggedIn')) {
            return redirect()->to('/login');
        }

        return view('admin_dashboard');
    }
}
