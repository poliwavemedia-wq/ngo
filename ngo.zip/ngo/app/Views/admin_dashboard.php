<!DOCTYPE html>
<html lang="en" class="app">
<head>
    <meta charset="utf-8" />
    <title>NGO Admin Dashboard</title>
    <meta name="description" content="NGO Admin Dashboard" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    
    <!-- CSS Links -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.2.0/remixicon.css"/>
    
    <!-- Using the same theme CSS from your original file for consistent look -->
    <link rel="stylesheet" href="https://shriramnavyugtrust.org/software/public/css/font.css" type="text/css" />
    <link rel="stylesheet" href="https://shriramnavyugtrust.org/software/public/css/app.v1.css" type="text/css" />
    
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?= base_url('websiteLogoImages/1737270034.png') ?>"/>

    <style>
        /* Custom styles for better presentation */
        body {
            font-family: 'Arial', sans-serif;
        }
        .user_middlebar_box {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .user_middlebar_box:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
        .all_details_heading {
            border-bottom: 2px solid #eee;
            padding-bottom: 10px;
            margin-top: 25px;
            margin-bottom: 20px;
            font-size: 1.5rem;
            font-weight: 600;
        }
        .nav>li>a {
            position: relative;
        }
        .nav>li>a>.badge {
            position: absolute;
            top: 10px;
            right: 15px;
            transform: none !important; /* Reset transform for better placement */
        }
    </style>
</head>
<body class="">
    <section class="vbox">
        <!-- Header -->
        <header class="bg-dark dk header navbar navbar-fixed-top-xs">
            <div class="navbar-header aside-md">
                <a class="btn btn-link visible-xs" data-toggle="class:nav-off-screen,open" data-target="#nav,html">
                    <i class="fa fa-bars"></i>
                </a>
                <a href="<?= base_url('admin/dashboard') ?>" class="navbar-brand" style="color: white;">
                    <!-- Your Logo and Trust Name -->
                    <img src="<?= base_url('websiteLogoImages/1737270034.png') ?>" style="height: 25px; vertical-align: middle;">
                    <span style="text-transform: capitalize; vertical-align: middle; margin-left: 10px;">NGO Trust</span>
                </a>
                <a class="btn btn-link visible-xs" data-toggle="dropdown" data-target=".nav-user">
                    <i class="fa fa-cog"></i>
                </a>
            </div>
            
            <ul class="nav navbar-nav navbar-right m-n hidden-xs nav-user">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <span class="thumb-sm avatar pull-left">
                            <img src="<?= base_url('images/admin_profile.png') ?>" alt="Admin">
                        </span>
                        <?= $admin_name ?? 'Admin Name' ?> <b class="caret"></b>
                    </a>
                    <ul class="dropdown-menu animated fadeInRight">
                        <span class="arrow top"></span>
                        <li><a href="<?= base_url('admin/profile') ?>">Profile</a></li>
                        <li class="divider"></li>
                        <li><a href="<?= base_url('logout') ?>">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </header>

        <section>
            <section class="hbox stretch">
                <!-- Sidebar -->
                <aside class="bg-dark lter aside-md hidden-print hidden-xs" id="nav">
                    <section class="vbox">
                        <header class="header bg-primary lter text-center clearfix">
                            <div class="btn-group">
                               <a href="<?= base_url('admin/dashboard') ?>" class="btn btn-sm btn-dark">Dashboard</a>
                            </div>
                        </header>
                        <section class="w-f scrollable">
                            <div class="slim-scroll" data-height="auto" data-disable-fade-out="true" data-distance="0" data-size="5px" data-color="#333333">
                                <nav class="nav-primary hidden-xs">
                                    <ul class="nav">
                                        <li>
                                            <a href="<?= base_url('admin/members/new') ?>">
                                                <i class="fa fa-users icon"><b class="bg-success"></b></i>
                                                <span>New Memberships</span>
                                                <b class="badge bg-danger pull-right"><?= $new_members ?? '0' ?></b>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?= base_url('admin/members/active') ?>">
                                                <i class="fa fa-id-card icon"><b class="bg-success"></b></i>
                                                <span>Active Members</span>
                                                <b class="badge bg-danger pull-right"><?= $active_members ?? '0' ?></b>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?= base_url('admin/certificates/generate') ?>">
                                                <i class="fa fa-certificate icon"><b class="bg-success"></b></i>
                                                <span>Generate Certificate</span>
                                            </a>
                                        </li>
                                         <li>
                                            <a href="<?= base_url('admin/donations/cash') ?>">
                                                <i class="fa fa-money icon"><b class="bg-success"></b></i>
                                                <span>Cash Donation</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?= base_url('admin/reports') ?>">
                                                <i class="fa fa-download icon"><b class="bg-success"></b></i>
                                                <span>Reports</span>
                                            </a>
                                        </li>
                                         <li>
                                            <a href="<?= base_url('admin/settings') ?>">
                                                <i class="fa fa-cogs icon"><b class="bg-success"></b></i>
                                                <span>Settings</span>
                                            </a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </section>
                    </section>
                </aside>

                <!-- Main Content -->
                <section id="content">
                    <section class="vbox">
                        <section class="scrollable padder">
                            <ul class="breadcrumb no-border no-radius b-b b-light pull-in">
                                <li><a href="<?= base_url('admin/dashboard') ?>"><i class="fa fa-home"></i> Home</a></li>
                                <li class="active">Admin Dashboard</li>
                            </ul>
                            <div class="m-b-md">
                                <h3 class="m-b-none">Admin Dashboard</h3>
                                <small>Welcome back, <?= $admin_name ?? 'Admin' ?></small>
                            </div>

                            <!-- Stats Cards -->
                            <section class="admin_middlebar_box">
                                <!-- Member Stats -->
                                <h3 class="all_details_heading">Members</h3>
                                <div class="row">
                                    <div class="col-lg-3 col-md-6 col-sm-6">
                                        <a href="<?= base_url('admin/members') ?>">
                                            <div class="user_middlebar_box">
                                                <i class="fa fa-users icon pull-left"></i>
                                                <div class="text-right">
                                                    <h3 class="placeorder_heading"> <?= $total_members ?? '376' ?></h3>
                                                    <h6 class="placeorder_heading_1">Total Members</h6>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-lg-3 col-md-6 col-sm-6">
                                        <a href="<?= base_url('admin/members/new') ?>">
                                            <div class="user_middlebar_box" style="background: linear-gradient(-45deg, #58326e, #e048a2);">
                                                <i class="fa fa-user-plus icon pull-left text-white"></i>
                                                <div class="text-right">
                                                    <h4 class="placeorder_heading text-white"><?= $new_members ?? '91' ?></h4>
                                                    <h6 class="placeorder_heading_1 text-white">New Memberships</h6>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-lg-3 col-md-6 col-sm-6">
                                        <a href="<?= base_url('admin/members/active') ?>">
                                            <div class="user_middlebar_box" style="background: linear-gradient(-45deg, #b02cd3, #0ee7aa);">
                                                <i class="fa fa-id-card icon pull-left text-white"></i>
                                                <div class="text-right">
                                                     <h4 class="placeorder_heading text-white"><?= $active_members ?? '284' ?></h4>
                                                    <h6 class="placeorder_heading_1 text-white">Active Members</h6>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-lg-3 col-md-6 col-sm-6">
                                        <a href="<?= base_url('admin/members/blocked') ?>">
                                            <div class="user_middlebar_box" style="background: linear-gradient(45deg, #e9ad2d, #ec4630);">
                                                <i class="fa fa-ban icon pull-left text-white"></i>
                                                <div class="text-right">
                                                    <h4 class="placeorder_heading text-white"><?= $blocked_members ?? '1' ?></h4>
                                                    <h6 class="placeorder_heading_1 text-white">Blocked Members</h6>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>

                                <!-- Donation Stats -->
                                <h3 class="all_details_heading">Donations</h3>
                                <div class="row">
                                     <div class="col-lg-3 col-md-6 col-sm-6">
                                        <a href="<?= base_url('admin/donations/membership') ?>">
                                            <div class="user_middlebar_box" style="background: linear-gradient(-45deg, #14202c, #21e2e4);">
                                                <i class="fa fa-money icon pull-left text-white"></i>
                                                <div class="text-right">
                                                     <h4 class="placeorder_heading text-white">₹<?= number_format($membership_fee ?? 7500) ?></h4>
                                                    <h6 class="placeorder_heading_1 text-white">Membership Fee</h6>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-lg-3 col-md-6 col-sm-6">
                                        <a href="<?= base_url('admin/donations/users') ?>">
                                            <div class="user_middlebar_box" style="background: linear-gradient(-45deg, #27ae60, #2ecc71);">
                                                 <i class="ri-hand-coin-fill icon pull-left text-white"></i>
                                                <div class="text-right">
                                                     <h4 class="placeorder_heading text-white">₹<?= number_format($user_donations ?? 18156876) ?></h4>
                                                    <h6 class="placeorder_heading_1 text-white">Users Donations</h6>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-lg-3 col-md-6 col-sm-6">
                                        <a href="<?= base_url('admin/donations/visitors') ?>">
                                            <div class="user_middlebar_box" style="background: linear-gradient(-45deg, #2980b9, #3498db);">
                                                <i class="fa fa-credit-card icon pull-left text-white"></i>
                                                <div class="text-right">
                                                     <h4 class="placeorder_heading text-white">₹<?= number_format($visitor_donations ?? 81483035) ?></h4>
                                                    <h6 class="placeorder_heading_1 text-white">Visitor Donations</h6>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                     <div class="col-lg-3 col-md-6 col-sm-6">
                                        <a href="<?= base_url('admin/donations/cash') ?>">
                                            <div class="user_middlebar_box" style="background: linear-gradient(45deg, #f39c12, #f1c40f);">
                                                <i class="fa fa-money icon pull-left text-white"></i>
                                                <div class="text-right">
                                                    <h4 class="placeorder_heading text-white">₹<?= number_format($cash_donations ?? 452467) ?></h4>
                                                    <h6 class="placeorder_heading_1 text-white">Cash Donations</h6>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </section>
                            
                            <!-- You can add more sections like charts or recent activity tables here -->
                            
                        </section>
                    </section>
                    <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen, open" data-target="#nav,html"></a>
                </section>
            </section>
        </section>
    </section>

    <!-- jQuery and other scripts -->
    <script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
    <script src="https://shriramnavyugtrust.org/software/public/js/app.v1.js"></script>
    <script src="https://shriramnavyugtrust.org/software/public/js/app.plugin.js"></script>
</body>
</html>
